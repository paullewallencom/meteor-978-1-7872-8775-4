
Description
===========

Chapter 8
---------
This chapters examples contains the app with deny and allow rules, as well as a method to add new posts.


Make the example work
---------------------

Install Meteor if you haven't:

	$ curl https://install.meteor.com/ | sh

cd into the folder of the example code and run

    $ meteor
