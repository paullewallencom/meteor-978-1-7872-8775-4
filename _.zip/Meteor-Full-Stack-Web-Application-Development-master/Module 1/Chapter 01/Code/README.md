
Description
===========

Chapter 1
---------
This chapters example contains the basic application structure which we will need later on in the book and the style files inside `client/styles`.


Make the example work
---------------------

Install Meteor if you haven't:

	$ curl https://install.meteor.com/ | sh

cd into the folder of the example code and run

    $ meteor

