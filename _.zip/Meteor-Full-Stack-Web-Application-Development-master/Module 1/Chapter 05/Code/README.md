
Description
===========

Chapter 5
---------
This chapters examples contain the app with add routes!


Make the example work
---------------------

Install Meteor if you haven't:

	$ curl https://install.meteor.com/ | sh

cd into the folder of the example code and run

    $ meteor