
Description
===========

Chapter 11
---------
This chapters examples contain only the package code.
The full app is available in the code example of chapter 10.


Make the example work
---------------------

You need to copy the "reactive-timer" folder into your app's "packages" folder
and run the following command from inside you app's folder to add the package:

$ meteor add meteor-book:reactive-timer