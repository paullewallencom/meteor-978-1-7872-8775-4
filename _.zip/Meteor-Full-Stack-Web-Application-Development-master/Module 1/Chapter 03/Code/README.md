
Description
===========

Chapter 3
---------
This chapters examples contains the first database examples.


Make the example work
---------------------

Please follow the instructions in chapter one of the book to install Meteor and its dependencies. As a short reminder:

		$ curl https://install.meteor.com/ | sh

