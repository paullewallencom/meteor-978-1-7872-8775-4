// #Storing Data -> Setup a collection
Posts = new Mongo.Collection('posts');