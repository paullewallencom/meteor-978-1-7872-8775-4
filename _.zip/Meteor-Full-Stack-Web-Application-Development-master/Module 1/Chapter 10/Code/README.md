
Description
===========

Chapter 10
---------
This code contains the ready to deploy app!

Note: This app won't create any dummy posts on start, so that the user can create its own.


Make the example work
---------------------

Install Meteor if you haven't:

	$ curl https://install.meteor.com/ | sh

cd into the folder of the example code and run

    $ meteor
