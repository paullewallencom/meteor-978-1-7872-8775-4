
Description
===========

Chapter 6
---------
This chapters examples contain the examples for using sessions.


Make the example work
---------------------

Install Meteor if you haven't:

	$ curl https://install.meteor.com/ | sh

cd into the folder of the example code and run

    $ meteor
