
Description
===========

Chapter 12
---------
This chapters examples include the app with tests
and the meteor-book:reactive-timer package we've build in chapter 11 containing now tests.


Make the example work
---------------------

Install Meteor if you haven't:

	$ curl https://install.meteor.com/ | sh

cd into the folder of the example code and run

    $ meteor

