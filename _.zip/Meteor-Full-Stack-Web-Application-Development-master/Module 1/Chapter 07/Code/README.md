
Description
===========

Chapter 7
---------
This chapters examples the app with login and admin user to create and edit posts.


Make the example work
---------------------

Install Meteor if you haven't:

	$ curl https://install.meteor.com/ | sh

cd into the folder of the example code and run

    $ meteor
