Template.firstTemplate.helpers({
  rawInsert: function () {
    return "<div><strong>Raw HTML!</strong></div>";
  }
});
