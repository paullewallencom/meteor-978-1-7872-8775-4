Meteor.methods({
  serverlog : function(msg){
    console.log(msg);
  }
});
